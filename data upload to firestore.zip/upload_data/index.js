const admin = require('firebase-admin');
const csv = require('csvtojson');
const serviceAccount = require('./token.json');
const {readFileSync} = require("node:fs");

admin.initializeApp({
    credential: admin.credential.cert(serviceAccount)
});

const db = admin.firestore();

async function importHopsCSVToFirestore(csvFilePath, collectionName) {
    try {
        const csvData = readFileSync(csvFilePath, 'utf8');
        const data = await csv({ delimiter: ';' }).fromString(csvData);

        const hopsDocRef = db.collection('ingredients').doc('hops');
        const hopsData = {};
        data.forEach(row => {
            const key = row.name ? row.name : 'undefined';
            hopsData[key] = row;
        });
        await hopsDocRef.set(hopsData);
        console.log(`Data imported to Firestore collection: ${collectionName}`);
    } catch (error) {
        console.error('Error importing data:', error);
    }
}

async function importMaltsCSVToFirestore(csvFilePath, collectionName) {
    try {
        const csvData = readFileSync(csvFilePath, 'utf8');
        const data = await csv({ delimiter: ';' }).fromString(csvData);

        const maltsDocRef = db.collection('ingredients').doc('malts');
        const maltsData = {};
        data.forEach(row => {
            const key = row.name ? row.name : 'undefined';
            maltsData[key] = row;
        });
        await maltsDocRef.set(maltsData);
        console.log(`Data imported to Firestore collection: ${collectionName}`);
    } catch (error) {
        console.error('Error importing data:', error);
    }
}

async function importYeastsCSVToFirestore(csvFilePath, collectionName) {
    try {
        const csvData = readFileSync(csvFilePath, 'utf8');
        const data = await csv({ delimiter: ';' }).fromString(csvData);

        const yeastsDocRef = db.collection('ingredients').doc('yeasts');
        const yeastsData = {};
        data.forEach(row => {
            const key = row.name ? row.name : 'undefined';
            yeastsData[key] = row;
        });
        await yeastsDocRef.set(yeastsData);
        console.log(`Data imported to Firestore collection: ${collectionName}`);
    } catch (error) {
        console.error('Error importing data:', error);
    }
}

importHopsCSVToFirestore('hop.csv', 'ingredients')
importMaltsCSVToFirestore('malt.csv', 'ingredients')
importYeastsCSVToFirestore('yeast.csv', 'ingredients')